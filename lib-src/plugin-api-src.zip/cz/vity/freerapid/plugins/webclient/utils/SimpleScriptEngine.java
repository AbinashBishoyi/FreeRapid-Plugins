package cz.vity.freerapid.plugins.webclient.utils;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 * @author Vity
 */
public class SimpleScriptEngine {
    public ScriptEngine getSimpleScriptEngine() {
        ScriptEngineManager mgr = new ScriptEngineManager();
        ScriptEngine jsEngine = mgr.getEngineByName("JavaScript");
        try {
           jsEngine.eval("importPackage(javax.swing);" +
               "var optionPane = " +
               "  JOptionPane.showMessageDialog(null, 'Hello, world!');");
         } catch (ScriptException ex) {
           ex.printStackTrace();
         }

        return jsEngine;
    }

    public static void main(String[] args) {
        new SimpleScriptEngine().getSimpleScriptEngine();
    }
}
